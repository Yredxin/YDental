# 新门店与员工准备

当前准备：**ENVIRONMENT_NOT_READY**。本页是流程导航；所有用户用例初始 NOT_RUN，用户结果只填写在各功能用例中。

**逻辑对象：** `SC01-ORG-A`、`SC01-STAFF-A`、`SC01-SPACE-A`、`SC01-RESOURCE-A`、`SC01-SCHEDULE-A`、`SC01-SUPPLY-A`、`SC01-DAY-A`、`SC01-PRICE-A` 与 `SC05-LOT-A`。这些是未来分配的逻辑编号，并非数据库 ID；先按[合成对象映射](../../00-guide/scenario-data-map.md)由负责人核验实际对应与状态，再按[唯一执行清单](../../00-guide/execution-checklist.md)执行或接续。结果记录在唯一原始用例对应 RUN-ID；同一来源已执行动作只引用原记录，不重复提交。

**目的与价值：** 准备组织、人员、空间和合法容量，为后续岗位提供可追溯的合成测试基础。
**参与岗位与交接：** [集团管理](../../10-roles/group-admin/README.md) → [店长](../../10-roles/store-manager/README.md) → [仓库](../../10-roles/warehouse/README.md) → [前台](../../10-roles/front-desk/README.md)。箭头表示主要协作，并非授权或严格身份切换；各步骤以其岗位为准。
**前置准备：** 已确认固定候选的独立环境、获授权组织管理员、唯一合成员工信息、两门店和空间方案；不得使用历史账号。
**起始对象与终止状态：** 起始：获准的测试组织与新合成人员；终止：有权账号、空间、排班、可售容量和营业日已准备或记录阻断。

| 步骤 | 承接岗位 | 流程动作 | 唯一功能用例 | 用户应观察 |
| --- | --- | --- | --- | --- |
| 1 | 集团管理／店长 | 建立门店与员工关系 | [UAT-ACC-001](../../30-functions/access/cases/UAT-ACC-001.md) | 记录页面中可见的员工及门店；未能独立读回门店创建时留待确认。 |
| 2 | 集团管理／店长 | 按类别配置及预览授权 | [UAT-ACC-002](../../30-functions/access/cases/UAT-ACC-002.md) | 权限预览与目标账号及门店匹配；名称本身不赋权。 |
| 3 | 空间配置人员 | 建立楼层、区域与工位 | [UAT-SPC-001](../../30-functions/space-scheduling/cases/UAT-SPC-001.md) | 核对各空间与工位的从属及能力。 |
| 4 | 集团资源管理员／空间配置人员 | 准备并放置资源 | [UAT-SPC-002](../../30-functions/space-scheduling/cases/UAT-SPC-002.md) | 资源与所在位置及能力可追溯。 |
| 5 | 排班人员与员工 | 安排排班并查看我的今日 | [UAT-SCH-001](../../30-functions/space-scheduling/cases/UAT-SCH-001.md) | 日期、门店、员工与建议入口匹配。 |
| 6 | 容量人员 | 准备容量及合规可售供给 | [UAT-SCH-002](../../30-functions/space-scheduling/cases/UAT-SCH-002.md) | 区分可售测试模式与不可售 demo；策略未知即停止。 |
| 7 | 容量人员／前台 | 按区域核对营业日 | [UAT-SCH-003](../../30-functions/space-scheduling/cases/UAT-SCH-003.md) | 记录开停接及恢复；不得覆盖既有日记录。 |
| 8 | 仓库 | 准备新批次及模拟收货 | [UAT-INV-001](../../30-functions/inventory-pharmacy/cases/UAT-INV-001.md) | 记录可见数量、批次与库存移动，供后续发药。 |
| 9 | 价目维护者 | 准备门店服务与价格映射 | [UAT-INT-001](../../30-functions/intake-queue/cases/UAT-INT-001.md) | 服务、能力及演示价映射满足后续预约。 |

**一次性业务提交：** 新建员工、授权替换、空间／资源变更、排班、容量、营业日和收货均为持久提交。
**停止而非重放：** 对象或登录名冲突、供给政策／身份未知、区域已有营业日记录、提交结果不明时停止；不要重复开户、收货或重开历史日。

每步只在对应功能用例执行并记录。已提交的同一业务来源不得重放；若需验收另一独立支线，按用例前置准备不同的新合成对象，可再次执行该用例并分别记录。场景引用已有结果时只接续或查看，不重复提交。若指定用例前置不足，记录 BLOCKED。

**结束与后续：** 达到上方终止状态后，可进入 [下一场景](../02-intake-queue/README.md)，或返回 [场景与手册总入口](../../README.md) 选择支线。

## 1.1 独立补充支线

[UAT-ACC-004](../../30-functions/rework-access-patient/cases/UAT-ACC-004.md) · [UAT-ACC-005](../../30-functions/rework-access-patient/cases/UAT-ACC-005.md)

以[执行清单](../../00-guide/execution-checklist.md)新增独立分支和[对象映射](../../00-guide/scenario-data-map.md)为准；仅接续已明确关联的原始 RUN，同一已提交来源不重放，数据未准备时停止。
