# 外加工协调

当前环境 **ENVIRONMENT_NOT_READY**；所有用户用例初始 **NOT_RUN**。本岗位是业务体验身份，不是固定权限模板或自动授权。先由负责人核对实际账号、当前门店、允许公司范围、类别等级及业务前置；只用独立合成数据。

## 职责与门诊作用

协调医生、采购、仓库与复诊岗位处理合成加工工单和回货。

## 真实权限及范围

工单创建和推进由本店 medical write 医生执行；实物接收入库需 warehouse write；选择合法采购行需 purchase.group_purchase_user，责任人需 followup write 及有效员工公司范围。供应商资质由有权集团管理员处理。

16 个实际授权类别及等级说明参见 [岗位与权限矩阵](../../00-guide/role-permission-matrix.md)。业务能力、Odoo 组、门店成员关系与权限类别是不同条件，不能从岗位名互相推导。

## 推荐顺序与功能用例

按照列出的用例及其前置依赖顺序进行；跨岗位项只执行本账号承担的部分，其余交由有权人员完成。操作与原始结果只保存在对应的用例内。

[UAT-LAB-001](../../30-functions/followup-lab/cases/UAT-LAB-001.md) → [UAT-LAB-002](../../30-functions/followup-lab/cases/UAT-LAB-002.md)。工单会自动建立 waiting 复诊，入库后只读查看该关联计划。

[UAT-FUP-001](../../30-functions/followup-lab/cases/UAT-FUP-001.md) 是独立治疗来源的单独示例，不得对工单同一来源再次创建复诊计划。

每项先核各用例的页面、权限、数据和停止条件。观察桌面、平板、窄屏三档布局及实际浏览器、宽度、缩放，在原用例记录实际 UI 意见；不将不同岗位或设备的体验代填为 PASS。

## 参与的跨岗位场景

[复诊、转诊与外加工](../../20-scenarios/08-followup-lab/README.md)

## 常见异常与限制

岗位是协作视角，可由多个授权账号分担；采购行不匹配或来源不唯一时停止，外部供应商通道未授权。

任何持久提交结果不明、对象或权限不符、来源不能唯一识别时停止受影响动作，由环境负责人核对，切勿盲目重试。真实患者、资金、正式签署、外部通知与生产环境不在本资料制作授权内。

## 阶段记录入口

先在对应功能用例中填写实际结果，再在 [阶段完成登记](../../40-results/stage-status.md) 引用用例及问题编号；[问题汇总](../../40-results/issues.md) 和 [UI 意见](../../40-results/ui-feedback.md) 只索引原始记录。

## 1.1 补充用例

[UAT-LAB-003](../../30-functions/rework-lab-evidence/cases/UAT-LAB-003.md) · [UAT-LAB-004](../../30-functions/rework-lab-evidence/cases/UAT-LAB-004.md)

先核用例真实权限、前置和独立逻辑对象；其他岗位的动作由相应有权人员执行。
